---
title: "Pilot Lock Document: Semantic Drift of *Burnout* (Stage 1 Registered Report)"
---

**Status:** DRAFT. Fill in the bracketed items, then post this document, `config.yaml`, and `anchors.yaml` on OSF as a time-stamped registration **before** anyone views pilot data. The registration date becomes "[date]" in the manuscript.

**What this locks:** the component taxonomy, the anchor sentences, the coding guide, the candidate models, the two pilot gates and their thresholds, the model-selection rule, and the pilot sampling plan. The pilot validates the instrument and selects the model. It does not decide which components exist, and it never touches Glassdoor data.

# 1. Component Taxonomy

Each usage of *burnout* is assigned to exactly one category.

| Category | Definition |
|:--|:--|
| Exhaustion | Chronic depletion of physical or emotional energy attributed to work demands; feeling drained, used up, unable to recover (Maslach et al., 2001). |
| Cynicism / depersonalization | Detached, indifferent, or negative attitude toward the job, the organization, or the people served; mentally checking out. |
| Reduced professional efficacy | Feeling ineffective or incompetent at work; loss of a sense of accomplishment or of the ability to do the job well. |
| Depressive symptoms | Pervasive low mood, hopelessness, loss of interest or pleasure, or worthlessness that extends beyond work. |
| Ordinary tiredness | Short-lived, everyday fatigue or busyness that is expected to pass with rest and does not impair functioning. |
| Other/none | The usage conveys no person's state (see the coding guide). |

# 2. Coding Guide

**Unit.** One usage: the sentence containing *burnout* (or *burned out*, *burnt out*, *burn-out*) plus one adjacent sentence. Code only what the word conveys in this usage. Do not infer from information outside the excerpt.

**Coders.** Two trained coders code every pilot usage independently. They are blind to the date (the coding sheet shows no year) and do not discuss items until both are finished. Krippendorff's α is computed on the independent codes. Disagreements are then resolved by discussion, and the resolved labels are used for Gate 2.

**Decision rules.**

1. **Is a person's state described?** If not, code *other/none*. Examples: rates or statistics ("high burnout rate"), programs or policies ("burnout prevention training"), the word as a topic ("burnout is a buzzword"), generic advice without any state ("take breaks to avoid burnout"), and non-psychological senses (engine, rocket, or tyre burnout; sports-training jargon).
2. **Exhaustion vs. ordinary tiredness** (the hardest distinction). Code *exhaustion* if the depletion is chronic (weeks or longer, or recurring), attributed to work, or impairs functioning or recovery ("the weekend isn't enough"). Code *ordinary tiredness* if it is short-lived or situational, expected to resolve with rest, or hedged as mild ("a bit of burnout", "mini burnout"). If duration is unclear, code exhaustion when strong depletion language is present ("drained", "nothing left") and tiredness when it is absent.
3. **Depressive symptoms vs. cynicism.** Code *depressive symptoms* when low mood, hopelessness, or loss of joy extends to life outside work, or when depression is named. Code *cynicism* when the negativity is directed at the job, the organization, or the people served.
4. **Reduced efficacy.** Code this when the usage centres on competence, mistakes, productivity, or a lost sense of accomplishment.
5. **Mixed usages.** Code the component the usage most centrally conveys. If two are equally prominent, code the one stated first and tick the "mixed" column. Mixed items are reported.
6. **Uncertain items.** Code your best judgment and tick "unsure". Do not skip items.

**Training.** Before coding the pilot sample, coders practise on the anchor sentences, then on 30 usages from outside the pilot sample, discussing the practice codes afterward.

# 3. Candidate Models

Three open-weight models, each pinned to the commit hash recorded at download (see `config.yaml`):

- `bert-base-uncased`: a bidirectional encoder and the standard benchmark model in this literature.
- `roberta-large`: a bidirectional encoder.
- `Qwen/Qwen3-Embedding-0.6B`: an embedding model built on a large language model.

For each model and each layer, a usage's vector is the mean over the focal word's subword tokens. It is then L2-normalized and centered by subtracting the mean vector of 100,000 random tokens from the same corpus.

# 4. Gate 1: Semantic-Change Benchmark

**Data.** The SemEval-2020 Task 1 English data (Schlechtweg et al., 2020): 37 targets with gold graded change between two periods of the Clean Corpus of Historical American English.

**Procedure.** For each target, sample up to 200 usages per period at random (seed in `config.yaml`). Compute usage drift exactly as in the main study (mean cross-period cosine distance minus the mean within-period spread). Then compute the Spearman correlation with the gold graded-change scores for every model and layer.

**Threshold: ρ ≥ .40.** In published results, BERT with average pairwise distance reached about .46–.57 on this task across layer choices (Laicher et al., 2021). A minimum of .40 therefore requires a candidate to perform near the established contextual-model range without demanding state-of-the-art results.

# 5. Gate 2: Anchor Classification on *Burnout*

**Data.** A year-stratified random sample of 400 *burnout* usages from the pilot corpus (Section 7), coded by both coders under the guide above.

**Procedure.** For each model and layer:

1. Compute each anchor's vector for the focal word and average the anchors within each component to get a centroid.
2. Give each usage five features: its cosine similarity to each centroid.
3. Fit a multinomial logistic classifier (six classes; features standardized within each training fold; L2 penalty with C = 1) with stratified 5-fold cross-fitting. If coders could not reliably separate exhaustion from tiredness (α < .667 on that distinction), the two are merged before fitting, as the protocol requires.

**Recorded metrics.** Out-of-fold macro-F1, expected calibration error (10 bins, top label), multiclass Brier score, and the confusion matrix.

**Thresholds:** macro-F1 ≥ .70 and calibration error ≤ .05, the same values as control C3.

# 6. Model Selection

A model–layer combination passes if it meets both gates. Among the passing combinations, select the one with the highest Gate 1 correlation. If no combination passes both gates, H2 is not tested, as the protocol states. A component the classifier cannot measure is reported as a pilot result, not dropped or redefined.

# 7. Pilot Corpus and Sampling

**Corpus.** Hacker News comments, 2012–2022, retrieved through the public Hacker News search API. This is a public, non-Glassdoor corpus of writing about work, and it has author and thread fields that stand in for reviewer and firm when estimating clustering. [If you use a different public corpus, replace this paragraph before locking.]

**Usages.** Comments matching *burnout*, *burn-out*, *burned out*, or *burnt out*, split into sentences, with one adjacent sentence of context.

**Coding sample.** 400 usages, year-stratified with at least 20 per year, drawn at random with the locked seed.

**Other pilot outputs** (descriptive only; no confirmatory temporal effects are estimated):

- yearly frequencies of *burnout* and the candidate control terms;
- the control-word remote-work screen for 2019 versus 2021, using the rule in protocol §2;
- category shares and the classifier's confusion matrix;
- author- and thread-level intraclass correlations of category membership.

All of these feed the sample-size simulation.


# 8. Anchor Sentences

Twelve anchors per component. Each uses the focal word in that component's sense. Experts sort them blind (see `Expert_Anchor_Sort.xlsx`), and any anchor placed in its intended component by fewer than 80% of experts is revised before locking.

**Exhaustion.** Chronic depletion of physical or emotional energy attributed to work demands; feeling drained, used up, unable to recover.

1. The burnout here is real: after every sprint I'm completely drained and the weekend isn't enough to recover.
2. Months of 60-hour weeks left me burned out, with nothing left in the tank by Wednesday.
3. I hit burnout last spring; I woke up already exhausted and stayed that way for weeks.
4. Constant on-call duty is a recipe for burnout because you never get a full night's rest.
5. My burnout feels like a dead battery that no amount of sleep will recharge.
6. Two years of understaffing left me burned out and physically worn down every day.
7. The workload causes burnout; people come in tired and leave even more depleted.
8. I was so burnt out that I had no energy left for my family after work.
9. Burnout for me meant being emotionally drained by every meeting and every email.
10. If you join this team, expect burnout from the relentless pace and no time to recover.
11. Management keeps adding projects, and the burnout shows in how exhausted everyone looks.
12. I took leave because the burnout had worn me down to nothing, physically and emotionally.

**Cynicism / depersonalization.** Detached, indifferent, or negative attitude toward the job, the organization, or the people served; mentally checking out.

1. Burnout here shows up as people who just stopped caring about the customers.
2. I got so burned out that I stopped believing anything leadership said and just went through the motions.
3. The burnout turned me cynical; every new initiative felt like another pointless exercise.
4. After a while burnout made me treat clients like tickets to close rather than people.
5. You can see the burnout in how the senior staff roll their eyes at the mission statement.
6. I was burnt out and emotionally checked out, doing the minimum and caring about none of it.
7. Burnout made me detached from my team; I stopped engaging and kept my head down.
8. The burnout is less about being tired and more that nobody cares about the work anymore.
9. My burnout looked like resentment toward the company and indifference to the outcome.
10. Once burnout set in I quit volunteering ideas because I no longer saw the point.
11. Burned out nurses start to distance themselves from patients just to get through the shift.
12. The culture breeds burnout: people become bitter and stop trusting anyone above them.

**Reduced professional efficacy.** Feeling ineffective or incompetent at work; loss of sense of accomplishment or ability to do the job well.

1. Burnout made me feel like I couldn't do my job well anymore, no matter how hard I tried.
2. I was burned out and my work suffered; I stopped feeling that I accomplished anything.
3. The burnout shook my confidence; tasks I used to handle easily started to feel beyond me.
4. Part of my burnout was feeling useless, like nothing I did made a difference to the project.
5. Burnout here means good engineers start doubting whether they are any good at their jobs.
6. I knew it was burnout when I kept making mistakes I never used to make.
7. Burnt out, I felt incompetent in front of my team and dreaded every review.
8. The burnout left me unproductive; I'd stare at the same document for hours and get nothing done.
9. My burnout was the sense that I was failing at the job I was trained for.
10. Burnout robbed me of any feeling of achievement even when the launch went well.
11. When I was burned out I couldn't solve problems I'd normally find routine.
12. Burnout made me feel I was no longer good at my job or adding any value.

**Depressive symptoms.** Pervasive low mood, hopelessness, anhedonia, or worthlessness extending beyond work; clinical-depression-like states labeled as burnout.

1. The burnout spread to everything; I lost interest in hobbies and friends, not just work.
2. My burnout turned into a dark place where I felt hopeless about my whole life.
3. I was so burned out that I couldn't enjoy anything, even on vacation.
4. Burnout for me was crying most days and feeling worthless in general.
5. The burnout made me feel empty and sad all the time, at work and at home.
6. Calling it burnout undersells it; I felt hopeless and couldn't see a way forward.
7. Burnt out to the point that getting out of bed felt pointless on weekends too.
8. My burnout came with a constant heavy sadness that therapy eventually helped me name.
9. Burnout took away my joy in everything; nothing felt worth doing.
10. During my burnout I withdrew from everyone and felt like a failure as a person.
11. The burnout became a numbness that followed me home and into every part of my life.
12. I was burned out and despairing, sleeping badly and feeling hopeless about the future.

**Ordinary tiredness.** Short-lived, everyday fatigue or being busy, expected to resolve with rest; not chronic, not impairing.

1. Bit of burnout after the quarter-end rush, but a long weekend sorted me out.
2. I'm a little burned out from back-to-back meetings today, time for coffee.
3. Holiday season brings some burnout, but it's temporary and things calm down in January.
4. Feeling some burnout after the conference week; nothing a good night's sleep won't fix.
5. There's occasional burnout around deadlines, which is normal for any job.
6. Slight burnout from the move this week, back to normal on Monday.
7. Got a bit burnt out from the training marathon, but I'm fine after a day off.
8. Burnout is minimal here; you might feel tired after a busy launch, then it passes.
9. Some burnout during peak season, but the slow months balance it out.
10. I hit a mini burnout on Friday afternoon and logged off early.
11. The burnout is just the usual end-of-week tiredness, nothing serious.
12. A busy month gave me some burnout, but a short vacation fixed it.

# References

Laicher, S., Kurtyigit, S., Schlechtweg, D., Kuhn, J., & Schulte im Walde, S. (2021). Explaining and improving BERT performance on lexical semantic change detection. In *Proceedings of the 16th Conference of the European Chapter of the Association for Computational Linguistics: Student Research Workshop*.

Maslach, C., Schaufeli, W. B., & Leiter, M. P. (2001). Job burnout. *Annual Review of Psychology, 52*, 397–422.

Schlechtweg, D., McGillivray, B., Hengchen, S., Dubossarsky, H., & Tahmasebi, N. (2020). SemEval-2020 Task 1: Unsupervised lexical semantic change detection. In *Proceedings of the Fourteenth Workshop on Semantic Evaluation* (pp. 1–23).
